We strongly prefer to engage users via GitHub.  This
automatically preserves useful information for posterity
and provides a natural way to link to specific code.

Please create GitHub issues to request help of any kind,
including questions about the project.

If you prefer to communicate wtih the PRK community via
email, use parallel-research-kernels@googlegroups.com.
This list includes dozens of people who have an interest
in the project, not just the developers.  It is a good
forum for asking general questions, the answers to which
may be of interest to many users.

If GitHub issues does not work for you, you can email the
developers directly.  If all else fails, you can find
these in the Google Group history (see above).
