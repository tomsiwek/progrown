# Aligned memory

Berkeley UPC provides page-aligned memory by default.
One can modify this with the runtime environment variable `UPC_SHARED_ALLOC_ALIGN`.

See [`man upcrun`](http://upc.lbl.gov/docs/user/upcrun.html) for details.
